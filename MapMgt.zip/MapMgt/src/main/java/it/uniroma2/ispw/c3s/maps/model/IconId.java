package it.uniroma2.ispw.c3s.maps.model;


public class IconId {
    private int id;

    public IconId() {
        this.id = 0;
    }

    public IconId(int id) {
        this.id = id;
    }
}