package it.uniroma2.ispw.c3s.maps.model;

public class Evaluation {
    private String evaluation;

    public Evaluation(String evaluation) {
        this.evaluation = evaluation;
    }

    public String getEvaluation() {
        return evaluation;
    }
}

