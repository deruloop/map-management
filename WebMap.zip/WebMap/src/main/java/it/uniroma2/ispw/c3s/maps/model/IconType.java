package it.uniroma2.ispw.c3s.maps.model;

public class IconType {
    private String type;


    public IconType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}